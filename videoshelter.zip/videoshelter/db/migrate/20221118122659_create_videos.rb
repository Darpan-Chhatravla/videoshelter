class CreateVideos < ActiveRecord::Migration[7.0]
  def change
    create_table :videos do |t|
      t.references :category,   index: true
      t.references :user,       index: true
      t.string     :title,      null: false, default: ""
      t.string     :video_file, null: false, default: ""
      t.timestamps
    end
  end
end
