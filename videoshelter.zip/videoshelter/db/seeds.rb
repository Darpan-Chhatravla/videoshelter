#
# Create Categories
#
puts "Creating Categories..."
Category.create([{ name: 'Exercies' }, { name: 'Education' }, { name: 'Recipe' }])
Category.all.each do |category|
	puts "Created Category: #{category.id} : #{category.name}"
end

puts "===================================="

#
# Create Users
#
puts "Creating Users..."
[
	{name: 'Admin 1', email: 'admin1@videoshelter.com', password: '123456'},
	{name: 'Admin 2', email: 'admin2@videoshelter.com', password: '123456'},
	{name: 'Admin 3', email: 'admin3@videoshelter.com', password: '123456'}
].each do |record|
	user = User.new(email: record[:email], password: record[:password], name: record[:name])
	user.save
	user.confirm
	puts "Created User: #{user.id} : #{user.name}"
end
