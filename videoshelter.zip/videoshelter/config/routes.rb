Rails.application.routes.draw do
  devise_for :users, controllers: {
    sessions: 'users/sessions'
  }

  scope module: :api do
    namespace :v1 do
      resources :videos, only: [:index, :create]
      resources :categories, only: [:index]
      get '/user', to: 'users#index'
    end
  end

  root "home#index"
end
