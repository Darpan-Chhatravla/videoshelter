require 'rails_helper'

RSpec.describe "Categories", type: :request do
  describe "GET /index" do
    let(:user) { create(:user) }

    context 'Without active session should redirect to sign in path' do
      it 'returns redirect response' do
        get(v1_categories_path)
        expect(response).to redirect_to(user_session_path)
      end
    end

    context 'With active session to landing page' do
      before do
        sign_in user
      end

      it 'returns success response' do
        get(
          v1_categories_path,
          headers: {
            'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
          }
        )
        data = JSON.parse(response.body)["data"]

        expect(response.status).to eq 200
        expect(data.size).to eq Category.count
      end
    end
  end
end
