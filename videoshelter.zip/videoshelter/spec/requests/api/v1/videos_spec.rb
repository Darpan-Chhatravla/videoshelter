require 'rails_helper'

RSpec.describe Api::V1::VideosController, type: :request do
  let(:user) { create(:user) }
  let(:category) { create(:category) }

  describe "GET #index" do
    context 'Without active session should redirect to sign in path' do
      it 'returns redirect response' do
        get(v1_videos_path)
        expect(response).to redirect_to(user_session_path)
      end
    end

    context 'With active session to landing page' do
      before do
        sign_in user
      end

      it 'returns success response' do
        get_videos
        expect(response.status).to eq 200        
      end

      it 'returns success response with video' do
        video = create(:video, user: user)

        get_videos
        data = JSON.parse(response.body)["data"]

        expect(response.status).to eq 200
        expect(data[0]['id']).to eq(video.id)
        expect(data[0]['title']).to eq(video.title)
        expect(data[0]['category_name']).to eq(video.category_name)
        expect(data[0]['thumbnail_url']).to eq(video.video_file.thumb.url)
        expect(data[0]['video_url']).to eq(video.video_file.url)
      end    
    end
  end

  describe "POST #create" do
    before do
      sign_in user
    end

    it 'returns success response with new video' do
      post(
        '/v1/videos',
        params: {
          title: "Video Title 1",
          category_id: category.id,
          video_file: Rack::Test::UploadedFile.new('spec/fixtures/videos/v1_test.mp4', 'video/mp4')
        },
        headers: {
          'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
        }
      )
      data = JSON.parse(response.body)["data"]

      expect(response.status).to eq 200
      expect(data['status']).to eq 201
      expect(data['message']).to eq I18n.t('success.201_main')
    end

    it 'returns 400 response with blank title video' do
      post(
        '/v1/videos',
        params: {
          title: nil,
          category_id: category.id,
          video_file: Rack::Test::UploadedFile.new('spec/fixtures/videos/v1_test.mp4', 'video/mp4')
        },
        headers: {
          'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
        }
      )

      data = JSON.parse(response.body)["data"]
      expect(response.status).to eq 200
      expect(data['status']).to eq 400
      expect(data['message'].count).to eq(1)
    end

    it 'returns 400 response with blank category video' do
      post(
        '/v1/videos',
        params: {
          title: "Video Title 1",
          category_id: nil,
          video_file: Rack::Test::UploadedFile.new('spec/fixtures/videos/v1_test.mp4', 'video/mp4')
        },
        headers: {
          'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
        }
      )

      data = JSON.parse(response.body)["data"]
      expect(response.status).to eq 200
      expect(data['status']).to eq 400
      expect(data['message'].count).to eq(2)
    end

    it 'returns 400 response with blank video' do
      post(
        '/v1/videos',
        params: {
          title: "Video Title 1",
          category_id: category.id,
          video_file: nil
        },
        headers: {
          'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
        }
      )

      data = JSON.parse(response.body)["data"]
      expect(response.status).to eq 200
      expect(data['status']).to eq 400
      expect(data['message'].count).to eq(2)
    end

    it 'returns 400 response with invalid video' do
      post(
        '/v1/videos',
        params: {
          title: "Video Title 1",
          category_id: category.id,
          video_file: Rack::Test::UploadedFile.new('spec/fixtures/pdfs/p1_test.pdf', 'application/pdf')
        },
        headers: {
          'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
        }
      )

      data = JSON.parse(response.body)["data"]
      expect(response.status).to eq 200
      expect(data['status']).to eq 400
      expect(data['message'].count).to eq(1)
    end
  end

  private
  def get_videos
    get(
      v1_videos_path,
      headers: {
        'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
      }
    )
  end
end
