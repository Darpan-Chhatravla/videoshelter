require 'rails_helper'

RSpec.describe "Users", type: :request do
  describe "GET /index" do
    let(:user) { create(:user) }

    context 'With invalid HTTP_AUTHORIZATION session should return failed' do
      before do
        sign_in user
      end

      it 'returns failed response' do
        get(
          v1_user_path,
          headers: {
            'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).decoded_token
          }
        )

        data = JSON.parse(response.body)["data"]
        expect(response.status).to eq 401
      end
    end

    context 'With active session should return user info' do
      before do
        sign_in user
      end

      it 'returns success response' do
        get(
          v1_user_path,
          headers: {
            'HTTP_AUTHORIZATION' => JwtTokenAuth.new(user_id: user.id).encode_token
          }
        )
        data = JSON.parse(response.body)["data"]

        expect(response.status).to eq 200
        expect(data['id']).to eq user.id
        expect(data['email']).to eq user.email
        expect(data['name']).to eq user.name
      end
    end
  end
end
