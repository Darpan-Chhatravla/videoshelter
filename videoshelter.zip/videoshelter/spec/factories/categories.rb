FactoryBot.define do
  factory :category do
    name { Faker::Internet.name }
    created_at { DateTime.now }
    updated_at { DateTime.now }
  end
end
