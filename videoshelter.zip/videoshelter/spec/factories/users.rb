FactoryBot.define do
  factory(:user) do
    name { 'Admin' }
    email { 'admin1@videoshelter.com' }
    password { '123456' }
    password_confirmation { '123456' }
    confirmed_at { DateTime.now.utc }
    jti { SecureRandom.uuid }
  end

  trait :inactive do
    is_active { false }
  end

  trait :without_email do
    email { nil }
  end

  trait :with_last_sign_in_at do
    last_sign_in_at { DateTime.now() }
  end
end