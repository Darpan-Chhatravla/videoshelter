FactoryBot.define do
  factory (:video) do
    association :category, factory: :category
    association :user, factory: :user
    title { "Video Title 1" }
    video_file { Rack::Test::UploadedFile.new('spec/fixtures/videos/v1_test.mp4', 'video/mp4') }
  end

  trait :pdf_file do
    video_file { Rack::Test::UploadedFile.new('spec/fixtures/pdfs/p1_test.pdf', 'application/pdf') }
  end

  trait :without_title do
    title { "Video Title 1" }
  end

  trait :mov_file do
    video_file { Rack::Test::UploadedFile.new('spec/fixtures/videos/v3_test.mov', 'video/quicktime') }
  end
end