def test_file_path(test_document)
  File.expand_path(File.join("fixtures", test_document))
end