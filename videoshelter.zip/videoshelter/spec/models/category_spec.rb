require 'rails_helper'

RSpec.describe Category, type: :model do
  it "has a valid factory" do
    expect(build(:category)).to be_valid
  end

  describe "validations" do
    it "is valid with a name" do
      category = build(:category, name: SecureRandom.alphanumeric(10))
      expect(category).to be_valid
    end

    it "is not valid without a name" do
      category = build(:category, name: nil)
      category.valid?
      expect(category.errors.messages[:name]).to eq [I18n.t('activerecord.errors.models.category.attributes.name.can_not_blank')]
    end

    it "validates name length" do
      category = build(:category, name: SecureRandom.alphanumeric(21))
      expect(category).to_not be_valid
      expect(category.errors.messages[:name]).to eq [I18n.t('activerecord.errors.models.category.attributes.name.to_long_by_name')]
    end

    it "validates name uniqueness" do
      Category.create!(name: "Uniqueness")
      category = Category.new(name: "Uniqueness")
      expect(category).to_not be_valid
      expect(category.errors.messages[:name]).to eq [I18n.t('activerecord.errors.models.category.attributes.name.uniqueness_by_name')]
    end
  end
end
