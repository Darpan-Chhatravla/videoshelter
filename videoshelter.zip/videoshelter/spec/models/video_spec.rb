require 'rails_helper'

RSpec.describe Video, type: :model do
  it "has a valid factory" do
    expect(build(:video)).to be_valid
  end

  describe "associations" do
    context ":user" do
      it "should have a valid user" do
        video = build(:video)
        expect(video.user).to be_valid
      end
    end

    context ":category" do
      it "should have a valid category" do
        video = build(:video)
        expect(video.category).to be_valid
      end
    end
  end

  describe "validations" do
    it "is not valid without a title" do
      video = build(:video, title: nil)
      expect(video).to_not be_valid
      expect(video.errors.messages[:title]).to eq [I18n.t('activerecord.errors.models.video.attributes.title.can_not_blank')]
    end

    it "validates title length" do
      video = build(:video, title: SecureRandom.alphanumeric(51))
      expect(video).to_not be_valid
      expect(video.errors.messages[:title]).to eq [I18n.t('activerecord.errors.models.video.attributes.title.to_long_by_title')]
    end

    it "validates video file type" do
      video_pdf_file = FactoryBot.build(:video, :pdf_file)
      expect(video_pdf_file).to_not be_valid
      expect(video_pdf_file.errors.messages[:video_file]).to eq [I18n.t('activerecord.errors.models.video.attributes.video_file.file_type')]
    end

    it "validates mp4 is a valid video file type" do
      video = build(:video)
      expect(video).to be_valid
      expect(video.errors.messages[:video_file]).to eq []
    end

    it "validates mov is a valid video file type" do
      video_mov_file = FactoryBot.build(:video, :mov_file)
      expect(video_mov_file).to be_valid
      expect(video_mov_file.errors.messages[:video_file]).to eq []
    end
  end
end
