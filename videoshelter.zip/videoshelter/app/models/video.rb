class Video < ApplicationRecord
  include ActiveModel::Serialization

  #
  # Declarations
  #
  mount_uploader :video_file, VideoUploader

  #
  # Associations
  #
  belongs_to :user
  belongs_to :category

  #
  # Validations
  #
  validates(
    :title,
    presence: :can_not_blank,
    length: {
      maximum: 50,
      message: :to_long_by_title
    }
  )

  validates(
    :category,
    presence: true
  )

  validates(
    :user,
    presence: true
  )

  validates(
    :video_file, 
    presence: true
  )

  validates_size_of(
    :video_file,
    maximum: 200.megabytes,
    message: :max_size
  )

  validate :valid_content_type

  #
  # Instance Methods
  #
  def category_name
    self.category.name
  end

  private
  def valid_content_type
    errors.add(:video_file, :file_type) unless %w(video/mp4 video/quicktime).include? video_file&.file&.content_type
  end
end
