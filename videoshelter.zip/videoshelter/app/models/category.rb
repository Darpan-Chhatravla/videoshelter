class Category < ApplicationRecord
	#
	# Associations
	#
	has_many :videos, dependent: :destroy

	#
	# Validations
	#
	validates(
		:name,
		uniqueness: {
			message: :uniqueness_by_name
		},
		length: {
			maximum: 20,
			message: :to_long_by_name
		},
		presence: :can_not_blank
	)
end
