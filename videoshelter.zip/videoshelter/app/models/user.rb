class User < ApplicationRecord
  include Devise::JWT::RevocationStrategies::JTIMatcher
  #
  # Include devise modules
  #
  devise(
    :database_authenticatable,
    :registerable,
    :recoverable,
    :rememberable,
    :validatable,
    :confirmable,
    :lockable,
    :timeoutable,
    :trackable,
    :omniauthable,
    :jwt_authenticatable,
    jwt_revocation_strategy: JwtDenylist
  )

  #
  # Associations
  #
  has_many :videos, dependent: :destroy

  #
  # Validations [Didn't added validation for email & password. As new user registration is not part of this demo app]
  #

  #
  # Instance Method
  #
  def update_jti
    self.jti = SecureRandom.uuid
    self.save(validate: false)
  end
end