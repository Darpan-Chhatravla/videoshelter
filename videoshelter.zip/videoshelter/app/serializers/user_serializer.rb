class UserSerializer < ApplicationSerializer
	attributes(
    :id,
    :email,
    :name
  )
end