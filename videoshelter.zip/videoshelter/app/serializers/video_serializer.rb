class VideoSerializer < ApplicationSerializer
	attributes(
    :id,
    :title,
    :category_name,
    :thumbnail_url,
    :video_url
  )

  def category_name
  	object.category_name
  end

  def thumbnail_url
    object.video_file.thumb.url
  end

  def video_url
    object.video_file.url
  end
end