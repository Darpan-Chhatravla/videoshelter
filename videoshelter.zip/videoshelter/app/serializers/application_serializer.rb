class ApplicationSerializer < ActiveModel::Serializer
end
