class CategorySerializer < ApplicationSerializer
	attributes(
    :id,
    :name
  )
end