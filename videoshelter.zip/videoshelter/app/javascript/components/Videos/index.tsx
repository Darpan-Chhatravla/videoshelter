import React from 'react'
import ReactDOM from 'react-dom/client'
import Upload from './Upload'
import List from './List'


export const Videos = (props) => {
  return (
    <div className='container' style={styles.container}>
    <React.Fragment>
      <Upload/>
      <List/>
    </React.Fragment>
    </div>
  )
}

export default Videos

const styles = {
  container: {
    margin: '7%'
  }
}