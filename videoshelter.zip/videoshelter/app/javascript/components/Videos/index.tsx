import React from 'react'
import Upload from './Upload'
import List from './List'


const Videos = () => {
  return (
    <div className='container' style={styles.container}>
      <Upload/>
      <List/>
    </div>
  )
}

export default Videos

const styles = {
  container: {
    margin: '7%'
  }
}