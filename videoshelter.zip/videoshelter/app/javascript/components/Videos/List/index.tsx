import React from 'react'
import React, { useCallback, useEffect, useState } from 'react'
import ReactDOM from 'react-dom/client'
import Api from '../../Helpers/Api';
import Routes from '../../Helpers/Routes';
import Button from 'react-bootstrap/Button';
import VideoCard from './VideoCard';

export const List = () => {
  const [videos, setVideos] = useState([]);

  // Fetch current user videos
  const fetchCurrentVideo = useCallback(async () => {
    let response
    try {
      response = await Api.get(Routes.get_videos);
      setVideos(response);
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    const initialize = async () => {
      try {
        await Promise.all([fetchCurrentVideo()]);
      } catch (error) {        
        return;
      }
    }
    initialize()
  }, []);

  return (
    <div id='card-list'>
      {videos.map((video) => (
        <VideoCard
          key={video.id}
          id={video.id}
          title={video.title}
          category_name={video.category_name}
          thumbnail_url={video.thumbnail_url}
          video_url={video.video_url}
        />
      ))}
    </div>
  )
}

export default List