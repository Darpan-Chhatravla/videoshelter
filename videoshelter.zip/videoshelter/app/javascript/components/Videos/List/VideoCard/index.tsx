import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import React, { useCallback, useEffect, useState } from 'react'

const VideoCard = (props) => {
  return (
    <Card style={{ width: '18rem', float: 'left', marginRight: '15px', marginTop: '15px' }}>
      <Button variant="default" href={props.video_url} target="_blank" title={props.title}  ><Card.Img variant="top" src={props.thumbnail_url} title={props.title}/></Button>
      <Card.Body>
        <Card.Title>{props.title}</Card.Title>
        <Card.Text>
          {props.category_name}
        </Card.Text>
        <Button variant="primary" href={props.video_url} target="_blank">Play</Button>
      </Card.Body>
    </Card>
  )
}

export default VideoCard