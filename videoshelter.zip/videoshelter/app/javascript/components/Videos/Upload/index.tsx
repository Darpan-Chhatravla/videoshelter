import React, { useCallback, useEffect, useState } from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Api from '../../Helpers/Api';
import Routes from '../../Helpers/Routes';

const Upload = () => {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [title, setTitle] = useState([])
  const [category_id, setCategory] = useState('')
  const [video_file, setFile] = useState('')
  const [categories, setCategories] = useState([]);
  const [validationError, setValidationError] = useState(null);

  // Upload request to backend using multipart
  // Frontend Validation are good to reduce backed api call
  // For demo application it's ok to not have frontend validation
  const uploadRequest = useCallback(
    async file => {
      setValidationError(null);
      const video_params = {
        title: title,
        category_id: category_id
      };

      let videoFile
      videoFile = await Api.upload(Routes.upload_video, {
        type: 'video_file',
        blob: video_file,
        params: video_params
      });

      if (videoFile.status === 201){
        window.location = '/'
      }else if (videoFile.status === 400){
        setValidationError(videoFile.message.sort().join(', '));
      };
    }, []);

  // Fetch available categories
  const fetchCategories = useCallback(async () => {
    let response
    try {
      response = await Api.get(Routes.get_categories);
      setCategories(response);
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    const initialize = async () => {
      try {
        await Promise.all([fetchCategories()]);
      } catch (error) {
        return;
      }
    }
    initialize()
  }, []);

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Upload Video
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>New video</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div style={styles.validationError}>{validationError}</div>
          <Form encType="multipart/form-data">
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Title*</Form.Label>
              <Form.Control type="text" placeholder="Video Title" onChange={e => setTitle(e.target.value)} required/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Category*</Form.Label>
               <Form.Select aria-label="Default select example" onChange={e => setCategory(e.target.value)} required>
                <option>Select Category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Label>Vidoe File*</Form.Label>
              <Form.Control type="file" onChange={e => setFile(event.target.files[0])} required/>
              <Form.Text className="text-muted">
                Maximum file size: 200MB |
                Supported file types: [MP4 | MOV]
              </Form.Text>
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
            </Form.Group>
            <Modal.Footer>
              <Button variant="primary" onClick={uploadRequest}>
                Upload
              </Button>
            </Modal.Footer>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}

const styles = {
  validationError: {
    color: 'red'
  }
}

export default Upload