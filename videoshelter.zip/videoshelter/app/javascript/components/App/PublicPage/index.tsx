import React from 'react';
import SignIn from '../../SignIn';

// Public Pages includes all the screen do not requires authentications.
export const PublicPage = () => {
  return (
    <div className='sign-in-wrapper' style={styles.wrapper}>
      <div className='sign-in-box' style={styles.signInBox}>
      <SignIn/>
      </div>
    </div>
  )
}

export default PublicPage

const styles = {
  wrapper: {
    border: '1px solid grey',
    width: '50%',
    background: '#f2f1f1',
    marginLeft: '25%',
    marginTop: '10%'
  },
  signInBox: {
    margin: '100px'
  }
}