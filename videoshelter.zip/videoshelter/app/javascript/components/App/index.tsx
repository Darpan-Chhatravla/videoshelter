import React from 'react';
import ReactDOM from 'react-dom/client';
import PublicPage from './PublicPage';
import PrivatePage from './PrivatePage';
import Cookies from 'js-cookie'
import Api from '../Helpers/Api';
import Routes from '../Helpers/Routes';
import React, { useCallback, useEffect, useState } from 'react'

const App = () => {
  const isLogin = Boolean(Cookies.get('jwtToken'));
  const [currentUser, setCurrentUser] = useState({id: '', email: '', name: ''});

  // Fetch current user to show title
  const fetchCurrentUser = useCallback(async () => {
    let response
    try {
      response = await Api.get(Routes.get_current_user);
      setCurrentUser(response);
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    const initialize = async () => {
      try {
        await Promise.all([fetchCurrentUser()]);
      } catch (error) {
        return;
      }
    }
    initialize()
  }, []);

  // Conditional componenet loading
  if (isLogin){
    return <PrivatePage currentUser={currentUser.email}/>
  } else {
    return <PublicPage />
  };
};

export default App
