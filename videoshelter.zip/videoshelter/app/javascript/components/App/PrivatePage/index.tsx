import React from 'react';
import Button from 'react-bootstrap/Button';
import Videos from '../../Videos';
import SignOut from '../../SignIn/SignOut';

// Private Pages includes all the screen requires authentications. Here we have only one screen
const PrivatePage = (props) => {
  return (
    <div className='main'>
      <div className='header' style={styles.header}>
        <div className='header-text' style={styles.headertext}>Welcome | {props.currentUser}</div>
        <div className='sign-out' style={styles.button_signout}><SignOut/></div>
      </div>
      <Videos/>
    </div>
  )
}

export default PrivatePage

const styles = {
  header: {
    width: '100%',
    height: '50px',
    background: 'grey',
    color: 'white'
  },
  headertext: {
    textAlign: 'left',
    position: 'absolute',
    margin: '13px'

  },
  button_signout: {
    textAlign: 'right',
    position: 'absolute',
    width: '99%',
    marginTop: '13px'
  }
}
