import Routes from './Routes';
import Cookies from 'js-cookie'

const Api = {
  get: function(url, signal) {
    return fetch(`${url}`, {
      method: 'GET',
      headers: this._setAuthHeaders(),
      signal
    })
      .then(this._parseJSON)
      .then(this._checkStatus)
      .then(this._getData)
  },

  post: function (url, data, signal) {
    return fetch(`${url}`, {
      method: 'POST',
      headers: this._setAuthHeaders(),
      body: JSON.stringify(data),
      signal
    })
      .then(this._parseJSON)
      .then(this._checkStatus)
      .then(this._getData)
  },

  delete: function (url, data, signal) {
    return fetch(`${url}`, {
      method: 'DELETE',
      headers: this._setAuthHeaders(),
      body: JSON.stringify(data),
      signal
    })
      .then(this._parseJSON)
      .then(this._checkStatus)
      .then(this._getData)
  },

  upload: function (url, { type, blob, params={}}, signal) {
    let formData = new FormData()
    const isMultiple = Array.isArray(blob)
    if (isMultiple) {
      for (const file of blob) {
        formData.append(type, file)
      }
    } else {
      formData.append(type, blob)
    }
    for(const k in params){
      formData.append(k, params[k])
    }

    const authCookie = this._getAuthCookie()
    let authHeaders = {}
    const jwtToken = Cookies.get('jwtToken')

    if(jwtToken){
      authHeaders = {
        ...authHeaders,
        'Authorization': `Bearer ${jwtToken}`
      }
    }

    return fetch(`${url}`, {
      method: 'POST',
      headers: new Headers(authHeaders),
      body: formData,
      signal
    })
      .then(Api._parseJSON)
      .then(Api._checkStatus)
      .then(Api._getData)
  },

  _getAuthCookie: function () {
    let authCookie = Cookies.get('authentication')
    if (!authCookie && window.location.pathname.indexOf("register") > -1){
      authCookie = this._withoutTokenHeader()
    }
    return authCookie
  },

  _withoutTokenHeader: function() {
    return new Headers({
      'Content-Type': 'application/json'
    })
  },

  _setAuthHeaders: function( contentType = 'application/json' ) {
    const authCookie = this._getAuthCookie()
    const jwtToken = Cookies.get('jwtToken')
    let authHeaders = {}
    if(contentType)
      authHeaders = { 'Content-Type': contentType}
    if(jwtToken){
      authHeaders = {
        ...authHeaders,
        'Authorization': `Bearer ${jwtToken}`
      }
    }
    if (authCookie) {
      authHeaders = {
        ...authHeaders,
        'X-User-Token': authCookie.token
      }
    }
    return new Headers(authHeaders)
  },

  _checkStatus: function (json) {
    if (json.status === 401) {
      window.location.assign(window.location.origin)
      throw json
    }

    if (json.is_registered) {
      window.location.assign(window.location.origin + Routes.unregistered)
      throw json
    }

    if (json.is_disabled) {
      window.location.assign(window.location.origin + Routes.disabled)
      throw json
    }

    if (json.is_entity_user_disbaled) {
      window.location.assign(window.location.origin + Routes.entity_user_disbaled)
      throw json
    }

    if (json.status === 500) {
      window.location.assign(window.location.origin + Routes.internalServerError)
      throw json
    }

    if (json.status === 400) {
      if(json.messages && json.messages.errors && json.messages.errors.length > 0){
        displayMessage.apiError(json)
        throw json
      }
    }

    if (json.status === 404) {
      window.location.assign(window.location.origin + Routes.notFound)
      throw json
    }

    if (json.status === 403) {
      window.location.assign(window.location.origin + Routes.forbidden)
      throw json
    }

    if (json.status >= 200 && json.status < 300) {
      return json
    } else if (json.status == 300) {
      App.FlashMessages.addMessage('error', json.messages.errors[0])
      return json
    } else {
      throw json
    }
  },

  _parseJSON: function(response) {
    const jwtToken = response.headers.get('jwtToken');
    if(jwtToken){
      Cookies.set('jwtToken', jwtToken)
    }
    return response.json()
  },

  _parseBlob: function (response) {
    return response.blob()
  },

  _getData: function (json) {
    return json.data
  }
}
export default Api