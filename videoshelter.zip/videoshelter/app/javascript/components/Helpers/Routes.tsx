// Routes for V1
const Routes = {
  sign_in: '/users/sign_in',
  sign_out: '/users/sign_out',
  get_videos: `/v1/videos`,
  upload_video: '/v1/videos',
  get_categories: '/v1/categories',
  get_current_user: '/v1/user'
}

export default Routes
