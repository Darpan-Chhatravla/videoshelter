import React, { useCallback } from 'react'
import Api from '../../Helpers/Api';
import Routes from '../../Helpers/Routes';
import Cookies from 'js-cookie'

export const SignOut = () => {
  const onSignOut = useCallback(async () => {
    let response
    try {
      response = await Api.delete(Routes.sign_out);
      Cookies.remove('jwtToken')
      window.location = '/'
    } catch (error) {
      console.log(error);
    }
  }, []);

  return(
    <a onClick={onSignOut}>Sign Out</a>
  )
}

export default SignOut