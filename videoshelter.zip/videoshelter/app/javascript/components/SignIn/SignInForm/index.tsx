import React, { useCallback, useState } from 'react'
import Api from '../../Helpers/Api';
import Routes from '../../Helpers/Routes';
import Cookies from 'js-cookie'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

export const SignInForm = ({setOtpUserId}) => {
  const [errors, setErrors] = useState([])
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [validationError, setValidationError] = useState(null);

  const onSignIn = useCallback(async () => {
    const user = {
      email: email,
      password: password
    }
    try {
      await Api.post(Routes.sign_in, { user: user }).then(response => {
        if (response.status === 201){
          window.location = response.redirect_to
        } else if (response.status === 400) {
          setValidationError(response.error);
        };
      })
    } catch (error) {
      setEmail("")
      setPassword("")
    }
  })

  return (
    <Form>
      <div style={styles.validationError}>{validationError}</div>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" onChange={e => setEmail(e.target.value)}/>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" onChange={e => setPassword(e.target.value)}/>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Valid Test Users</Form.Label>
        <Form.Text className="text-muted"><br></br>
          Email: 'admin1@videoshelter.com' | Password: '123456'<br></br>
          Email: 'admin2@videoshelter.com' | Password: '123456'<br></br>
          Email: 'admin3@videoshelter.com' | Password: '123456'<br></br>
        </Form.Text>
      </Form.Group>

      <Button variant="primary" onClick={onSignIn}>
        Submit
      </Button>
    </Form>
  )
}

const styles = {
  validationError: {
    color: 'red'
  }
}

export default SignInForm
