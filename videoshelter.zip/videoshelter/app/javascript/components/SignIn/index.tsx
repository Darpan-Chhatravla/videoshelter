import React, { Fragment, useEffect, useState } from 'react'
import SignInForm from './SignInForm'

const SignIn = () => {
  return (
    <SignInForm />
  )
}

export default SignIn

