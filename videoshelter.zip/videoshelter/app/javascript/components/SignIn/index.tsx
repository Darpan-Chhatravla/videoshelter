import React, { Fragment, useEffect, useState } from 'react'
import { SignInForm } from './SignInForm'

export const SignIn = () => {
  return (
    <SignInForm />
  )
}

export default SignIn

