import 'bootstrap/dist/css/bootstrap.min.css';
import * as React from 'react'
import ReactDOM from 'react-dom/client';
import App from './components/App'

const Element = document.querySelector("#root");
const root = ReactDOM.createRoot(Element);

root.render(<App/>);