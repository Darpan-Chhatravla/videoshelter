import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react'
import ReactDOM from 'react-dom/client';
import App from './components/App'

const Element = document.querySelector("#root");
console.log(Element);
console.log('----------------');
const root = ReactDOM.createRoot(Element);

root.render(<App/>);