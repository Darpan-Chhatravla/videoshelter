class JwtTokenAuth
  attr_reader :token, :user_id

  def initialize(token: '', user_id: '')
    @token = token
    @user_id = user_id
  end

  def encode_token
    user = User.find(user_id)
    payload = {
      user_id: user_id, exp: user.class.timeout_in.from_now.to_i,
      jti: user.jti, scp: 'user'
    }
    JWT.encode(payload, Rails.application.credentials.jwt_secret)
  end

  def decoded_token
    jwt_token = token&.split(' ')&.last
    begin
      JWT.decode(jwt_token, Rails.application.credentials.jwt_secret).try(:first)
    rescue JWT::ExpiredSignature, JWT::VerificationError, JWT::DecodeError
      nil
    end
  end

  def user_from_token
    return nil if decoded_token&.dig('user_id').blank?
    User.find_by(id: decoded_token&.dig('user_id'))
  end
end
