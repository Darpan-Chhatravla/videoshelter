class ApplicationController < ActionController::Base
	skip_before_action :verify_authenticity_token

	before_action :authenticate_user!
	after_action :set_jwt_token_in_headers

	protected
  def run_object_serializer(object, each_serializer, options = {})
    children = options.fetch(:children, nil)
    options = {
      serializer: each_serializer,
      params: options.merge({current_user: current_user})
    }
    ActiveModelSerializers::SerializableResource.new(object, each_serializer: each_serializer).as_json
  end

  def render_success(serialized_data = {}, errors = nil, success = nil, options={})
    meta = options.fetch(:meta, nil)
    json = {
      date: Time.now.utc,
      status: 200,
      messages: { errors: errors, success: success },
      data: serialized_data,
      meta: meta
    }
    render(json: json)
  end

  def render_unauthorized(errors = [t("errors.unauthorized")])
    render(
      json: {
        date: Time.now.utc,
        messages: { errors: errors },
        status: 401
      },
      status: :unauthorized
    )
  end

  def set_jwt_token_in_headers
    return if current_user.blank?
    response.headers['jwtToken'] = JwtTokenAuth.new(user_id: current_user.id).encode_token
  end
end
