# frozen_string_literal: true

class Users::SessionsController < Devise::SessionsController
  before_action :check_locked_user!, except: [:destroy, :new]
  before_action :set_current_user, only: :destroy

  def create
    if user&.valid_password?(user_params[:password])
      sign_in_user
    else
      user&.increment_failed_attempts
      render_success({ status: 400, error: t('devise.failure.invalid', authentication_keys: 'Email') }) and return
    end
  end

  def destroy
    sign_out(current_user)
    @current_user = nil
    JwtDenylist.where('exp < ?', Time.current).destroy_all # Destroy expired tokens
    logout_url = '/?signed_out=true'
    if params.dig(:session, :using_sudomain) && params.dig(:session, :logout_url).present?
      logout_url = params.dig(:session, :logout_url)
    end

    render_success({ redirect_to: logout_url }, nil, t('devise.sessions.signed_out'))
  end

  private

  def user_params
    params.require(:user).permit(:email, :password)
  end

  def check_locked_user!
    render_unauthorized([t('devise.failure.locked')]) and return if user&.access_locked?
  end

  def sign_in_user
    user.update_jti
    sign_in(user, event: :authentication)
    jwt_token = JwtTokenAuth.new(user_id: user.id).encode_token
    render_success({ status: 201, redirect_to: '/', token: jwt_token })
  end

  def set_current_user
    warden.set_user(current_user, run_callbacks: false)
  end

  def user
    @user ||= User.find_by(email: user_params[:email]&.downcase)
  end
end
