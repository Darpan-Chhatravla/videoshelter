class Api::ApplicationController < ApplicationController
  before_action :require_login!

  private
  def get_current_user
    current_user ||= JwtTokenAuth.new(token: request.headers['HTTP_AUTHORIZATION']).user_from_token
  end

  def require_login!
    render_unauthorized([t('errors.401_invalid_auth_token')]) and return if get_current_user.blank?
  end
end