class Api::V1::VideosController < Api::V1::ApplicationController
  before_action :set_new, only: :create
  def index
    @videos = current_user.videos
    render_success(run_object_serializer(@videos, VideoSerializer))
  end

  def create
    if @video.save
      render_success({ status: 201, message: I18n.t('success.201_main') })
    else
      render_success({ status: 400, message: @video.errors.full_messages })
    end
  end

  private

  def set_new
    @video = current_user.videos.new(
      category_id: params[:category_id],
      title:       params[:title],
      video_file:  params[:video_file]
    )
  end
end