class Api::V1::CategoriesController < Api::V1::ApplicationController
  def index
    @categories = Category.all
    render_success(run_object_serializer(@categories, CategorySerializer))
  end
end