class Api::V1::UsersController < Api::V1::ApplicationController
	def index
		render_success(run_object_serializer(current_user, UserSerializer))
	end
end